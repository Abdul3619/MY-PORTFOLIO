import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !serviceKey) {
  console.error("Missing credentials.");
  process.exit(1);
}

async function testQuery() {
  // Try https://[ref].supabase.co/v1/query
  const url = `${supabaseUrl}/v1/query`;
  console.log("Sending query request to:", url);

  const body = JSON.stringify({
    query: "SELECT 1 as num;",
  });

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${serviceKey}`,
        'apikey': serviceKey
      },
      body,
    });

    console.log("Status:", res.status);
    console.log("Headers:", [...res.headers.entries()]);
    const text = await res.text();
    console.log("Body:", text);
  } catch (err: any) {
    console.error("Error sending request:", err.message);
  }
}

testQuery();
