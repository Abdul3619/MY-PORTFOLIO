import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

if (!supabaseUrl || !supabaseServiceKey) {
  console.error('Error: Supabase environment variables are missing.');
  process.exit(1);
}

const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

async function run() {
  console.log('Running reviews table creation migration...');
  
  const sql = `
    CREATE TABLE IF NOT EXISTS public.reviews (
      id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
      client_name TEXT NOT NULL,
      company TEXT,
      job_title TEXT,
      email TEXT NOT NULL,
      project_name TEXT,
      rating INTEGER NOT NULL CHECK (rating >= 1 AND rating <= 5),
      title TEXT NOT NULL,
      message TEXT NOT NULL,
      status TEXT NOT NULL DEFAULT 'Pending' CHECK (status IN ('Pending', 'Approved', 'Rejected')),
      created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
      approved_at TIMESTAMP WITH TIME ZONE,
      updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
      ip_address TEXT,
      browser TEXT
    );

    -- Enable Row Level Security if needed, or allow service_role to access it freely
    ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
    
    -- Create policy to allow all public read access on approved reviews
    CREATE POLICY "Allow public read of approved reviews" ON public.reviews
      FOR SELECT USING (status = 'Approved');

    -- Create policy to allow public inserts
    CREATE POLICY "Allow public insert of reviews" ON public.reviews
      FOR INSERT WITH CHECK (true);

    -- Create policy to allow all service role operations
    CREATE POLICY "Allow service role full access" ON public.reviews
      FOR ALL USING (true);
  `;

  const { data, error } = await supabaseAdmin.rpc('exec_sql', { sql_query: sql });
  if (error) {
    console.error("Error executing migration:", error);
    
    // If exec_sql RPC failed or isn't available, we can try to run it directly if possible,
    // or let's inspect the error to understand.
  } else {
    console.log("Reviews table migration completed successfully:", data);
  }
}

run();
