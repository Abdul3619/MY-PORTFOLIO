import dotenv from 'dotenv';
dotenv.config();
console.log("All environment keys:");
Object.keys(process.env).sort().forEach(key => {
  console.log(`- ${key}: length=${process.env[key]?.length}`);
});
