import fs from 'fs';
import path from 'path';

const envKeys = [
  'VITE_SUPABASE_URL',
  'VITE_SUPABASE_ANON_KEY',
  'APP_URL'
];

let envContent = '';
for (const key of envKeys) {
  if (process.env[key]) {
    envContent += `${key}="${process.env[key]}"\n`;
  }
}

// Include all other VITE_ prefixed environment variables
for (const [key, value] of Object.entries(process.env)) {
  if (key.startsWith('VITE_') && !envKeys.includes(key)) {
    envContent += `${key}="${value}"\n`;
  }
}

fs.writeFileSync(path.join(process.cwd(), '.env'), envContent);
console.log('Successfully generated .env file for client compilation with keys:', Object.keys(process.env).filter(k => k.startsWith('VITE_') || k === 'APP_URL'));
