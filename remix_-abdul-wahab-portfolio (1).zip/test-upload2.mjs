import fs from 'fs';
fs.writeFileSync('test.jpg', Buffer.alloc(1024 * 1024 * 2)); // 2MB dummy image

const blob = new Blob([fs.readFileSync('test.jpg')], { type: 'image/jpeg' });
const form = new FormData();
form.append('file', blob, 'test.jpg');

try {
  const res = await fetch('http://localhost:3000/api/upload', {
    method: 'POST',
    body: form
  });
  const text = await res.text();
  console.log("Status:", res.status);
  console.log("Response:", text.substring(0, 100));
} catch (e) {
  console.error("Error:", e);
}
