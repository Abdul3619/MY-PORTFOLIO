const project = { tech_stack: null };
try {
  const res = (project.tech_stack || project.techStack || []).slice(0, 2).map(stack => stack);
  console.log("Success:", res);
} catch (e) {
  console.error("Error:", e.message);
}
