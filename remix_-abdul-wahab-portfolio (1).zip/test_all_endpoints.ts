import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

const endpoints = [
  '/pg',
  '/query',
  '/sql',
  '/rest/v1/sql',
  '/rest/v1/query',
  '/rest/v1/rpc/exec_sql',
];

async function testEndpoints() {
  for (const ep of endpoints) {
    const url = `${supabaseUrl}${ep}`;
    console.log(`\nTesting endpoint: ${url}`);
    try {
      const res = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${serviceKey}`,
          'apikey': serviceKey
        },
        body: JSON.stringify({ query: 'SELECT 1 as num;', sql: 'SELECT 1 as num;' }),
      });
      console.log(`Status: ${res.status}`);
      const text = await res.text();
      console.log(`Body: ${text.substring(0, 200)}`);
    } catch (err: any) {
      console.error(`Error: ${err.message}`);
    }
  }
}

testEndpoints();
