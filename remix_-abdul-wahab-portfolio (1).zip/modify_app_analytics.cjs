const fs = require('fs');

let appContent = fs.readFileSync('src/App.tsx', 'utf-8');

appContent = appContent.replace(
  'if (seo?.site_title) {\n      document.title = seo.site_title;\n    }',
  `if (seo?.site_title) {
      document.title = seo.site_title;
    }
    
    if (seo?.google_analytics_id && !document.getElementById('ga-script')) {
      const script = document.createElement('script');
      script.id = 'ga-script';
      script.src = \`https://www.googletagmanager.com/gtag/js?id=\${seo.google_analytics_id}\`;
      script.async = true;
      document.head.appendChild(script);
      const script2 = document.createElement('script');
      script2.innerHTML = \`window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', '\${seo.google_analytics_id}');\`;
      document.head.appendChild(script2);
    }

    if (seo?.meta_pixel_id && !document.getElementById('fb-pixel')) {
      const script = document.createElement('script');
      script.id = 'fb-pixel';
      script.innerHTML = \`!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window, document,'script','https://connect.facebook.net/en_US/fbevents.js');fbq('init', '\${seo.meta_pixel_id}');fbq('track', 'PageView');\`;
      document.head.appendChild(script);
    }

    if (seo?.microsoft_clarity_id && !document.getElementById('clarity-script')) {
      const script = document.createElement('script');
      script.id = 'clarity-script';
      script.innerHTML = \`(function(c,l,a,r,i,t,y){c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y)})(window, document, "clarity", "script", "\${seo.microsoft_clarity_id}");\`;
      document.head.appendChild(script);
    }`
);

fs.writeFileSync('src/App.tsx', appContent, 'utf-8');
console.log("Updated App.tsx with Analytics injection");
