import fs from 'fs';

try {
  const files = fs.readdirSync('/');
  console.log("Container root directory files:", files);
} catch (err: any) {
  console.error("Error reading container root:", err.message);
}
