import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

const supabaseAdmin = createClient(supabaseUrl, supabaseServiceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

const tables = ['profiles', 'projects', 'skills', 'certificates', 'testimonials', 'contact_messages', 'reviews'];

async function run() {
  for (const table of tables) {
    const { data, error } = await supabaseAdmin.from(table).select('*').limit(1);
    if (error) {
      console.log(`Table '${table}' query error:`, error.message);
    } else {
      console.log(`Table '${table}' exists! Row count sample:`, data.length);
    }
  }
}
run();
