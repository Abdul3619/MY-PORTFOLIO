const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

content = content.replace(
  /if \(err\.message\?\.includes\('find the table'\) \|\| err\.message\?\.includes\('does not exist'\)\) \{/g,
  "if (err.message?.includes('find the table') || err.message?.includes('does not exist') || err.message?.includes('Could not find the column')) {"
);

fs.writeFileSync('server.ts', content, 'utf-8');
console.log("Updated error handling in server.ts");
