import fs from 'fs';
import path from 'path';

const envPath = path.join(process.cwd(), '.env');
console.log(".env exists:", fs.existsSync(envPath));

if (fs.existsSync(envPath)) {
  const content = fs.readFileSync(envPath, 'utf8');
  console.log("Lines in .env:");
  content.split('\n').forEach(line => {
    const parts = line.split('=');
    if (parts[0]) {
      console.log(`- ${parts[0].trim()}: (value length ${parts[1]?.length || 0})`);
    }
  });
} else {
  console.log("No .env file found in workspace root.");
}
