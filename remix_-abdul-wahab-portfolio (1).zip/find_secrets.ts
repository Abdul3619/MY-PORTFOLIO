import fs from 'fs';
import path from 'path';

const searchPaths = [
  '/run',
  '/var/run',
  '/etc',
  '/tmp'
];

function scanDir(dir: string, depth = 0) {
  if (depth > 2) return;
  try {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const fullPath = path.join(dir, file);
      if (file.toLowerCase().includes('secret') || file.toLowerCase().includes('credential')) {
        console.log(`Found matching file/dir: ${fullPath}`);
      }
      try {
        const stat = fs.statSync(fullPath);
        if (stat.isDirectory()) {
          scanDir(fullPath, depth + 1);
        }
      } catch (e) {}
    }
  } catch (err) {}
}

for (const p of searchPaths) {
  scanDir(p);
}
console.log("Scan complete.");
