const fs = require('fs');

let content = fs.readFileSync('src/pages/admin/AdminMedia.tsx', 'utf-8');

if (!content.includes('isDragging')) {
  content = content.replace(
    'const [copiedName, setCopiedName] = useState<string | null>(null);',
    'const [copiedName, setCopiedName] = useState<string | null>(null);\n  const [isDragging, setIsDragging] = useState(false);'
  );
}

const processFileFunction = `
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };
  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processFile(file);
    }
  };

  const processFile = async (file: File) => {
    setUploading(true);
    triggerToast('Ingestion Initiated', \`Uploading asset: \${file.name}...\`, 'info');
    try {
      const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetchApi('/api/upload', {
        method: 'POST',
        body: formData
      });
      
      const responseData = await response.json();
      if (responseData.error) throw new Error(responseData.error);
      
      const newAsset: MediaAsset = {
        name: responseData.name || file.name,
        id: Math.random().toString(36).substring(7),
        url: responseData.url || responseData.publicUrl,
        created_at: new Date().toISOString(),
        size: file.size,
        type: responseData.type || file.type
      };

      const updated = [newAsset, ...mediaAssets];
      setMediaAssets(updated);
      localStorage.setItem('media_library_cache', JSON.stringify(updated));

      try {
        await fetchApi('/api/admin/activity_log', {
          method: 'POST',
          body: JSON.stringify({
            action: 'Media Ingested',
            details: \`Uploaded file to CDN pipeline: \${file.name}\`
          })
        });
      } catch (e) {}
      triggerToast('Success', 'Asset uploaded successfully to CDN!', 'success');
      fetchAssetsAndLogs();
    } catch (err: any) {
      triggerToast('Error', err.message || 'Upload failed', 'danger');
    } finally {
      setUploading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    await processFile(file);
  };
`;

// Replace handleFileUpload block completely
content = content.replace(
  /const handleFileUpload = async \(e: React\.ChangeEvent<HTMLInputElement>\) => \{[\s\S]*?finally \{\s*setUploading\(false\);\s*\}\s*\};/,
  processFileFunction
);

content = content.replace(
  '<label className="border-2 border-dashed border-white/10 hover:border-[#00F0FF]/50 rounded-lg bg-[#161616]/50 hover:bg-[#161616] transition-colors p-6 flex flex-col items-center justify-center cursor-pointer interactive">',
  '<label \n                onDragOver={handleDragOver}\n                onDragLeave={handleDragLeave}\n                onDrop={handleDrop}\n                className={`border-2 border-dashed rounded-lg transition-colors p-6 flex flex-col items-center justify-center cursor-pointer interactive ${isDragging ? "border-[#00F0FF] bg-[#00F0FF]/10" : "border-white/10 hover:border-[#00F0FF]/50 bg-[#161616]/50 hover:bg-[#161616]"}`}>'
);

fs.writeFileSync('src/pages/admin/AdminMedia.tsx', content, 'utf-8');
console.log("Drag & Drop added");
