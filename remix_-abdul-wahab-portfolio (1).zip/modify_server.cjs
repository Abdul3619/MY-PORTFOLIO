const fs = require('fs');
let content = fs.readFileSync('server.ts', 'utf-8');

// Profile Schema
content = content.replace(
  'const profileSchema = z.object({',
  `const profileSchema = z.object({
  long_bio: z.string().optional().nullable(),
  tagline: z.string().optional().nullable(),
  cover_image_url: z.string().url().optional().nullable(),`
);

// SEO Schema
content = content.replace(
  'const seoSchema = z.object({',
  `const seoSchema = z.object({
  logo_url: z.string().url().optional().nullable(),
  site_name: z.string().optional().nullable(),
  footer_copyright: z.string().optional().nullable(),
  browser_title: z.string().optional().nullable(),
  meta_keywords: z.string().optional().nullable(),
  twitter_card_image: z.string().url().optional().nullable(),
  google_analytics_id: z.string().optional().nullable(),
  google_tag_manager_id: z.string().optional().nullable(),
  microsoft_clarity_id: z.string().optional().nullable(),
  meta_pixel_id: z.string().optional().nullable(),
  maintenance_mode: z.boolean().optional().nullable(),`
);

// Contact Info Schema
content = content.replace(
  'const contactInfoSchema = z.object({',
  `const contactInfoSchema = z.object({
  location: z.string().optional().nullable(),
  facebook_url: z.string().url().optional().nullable(),
  behance_url: z.string().url().optional().nullable(),
  dribbble_url: z.string().url().optional().nullable(),
  youtube_url: z.string().url().optional().nullable(),
  discord_url: z.string().url().optional().nullable(),`
);

// Catch schema missing error for profile, singletons
content = content.replace(
  "if (err.message?.includes('find the table') || err.message?.includes('does not exist')) {",
  "if (err.message?.includes('find the table') || err.message?.includes('does not exist') || err.message?.includes('Could not find the column')) {"
);

fs.writeFileSync('server.ts', content, 'utf-8');
console.log("Updated server.ts schemas");
