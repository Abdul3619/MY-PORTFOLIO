const fs = require('fs');

let content = fs.readFileSync('src/pages/admin/AdminMedia.tsx', 'utf-8');

content = content.replace(
  'name: file.name,',
  'name: responseData.name || file.name,'
);

content = content.replace(
  'type: file.type',
  'type: responseData.type || file.type'
);

fs.writeFileSync('src/pages/admin/AdminMedia.tsx', content, 'utf-8');
console.log("Fixed media names");
