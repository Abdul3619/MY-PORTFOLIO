const fs = require('fs');

let content = fs.readFileSync('src/pages/admin/AdminMedia.tsx', 'utf-8');

// Add fetchApi import
if (!content.includes('fetchApi')) {
  content = content.replace(
    "import { useAdmin } from '../../components/admin/AdminLayout';",
    "import { useAdmin } from '../../components/admin/AdminLayout';\nimport { fetchApi } from '../../hooks/useApi';"
  );
}

// Replace handleFileUpload logic
content = content.replace(
  /const fileName = `\$\{Date\.now\(\)\}_\$\{file\.name\.replace[^]*?catch \(e\) \{\}/,
  `const formData = new FormData();
      formData.append('file', file);
      
      const response = await fetchApi('/api/upload', {
        method: 'POST',
        body: formData
      });
      
      const responseData = await response.json();
      if (responseData.error) throw new Error(responseData.error);
      
      const newAsset: MediaAsset = {
        name: file.name,
        id: Math.random().toString(36).substring(7),
        url: responseData.url || responseData.publicUrl, // Depends on what /api/upload returns
        created_at: new Date().toISOString(),
        size: file.size,
        type: file.type
      };

      const updated = [newAsset, ...mediaAssets];
      setMediaAssets(updated);
      localStorage.setItem('media_library_cache', JSON.stringify(updated));

      // Append Audit Log
      try {
        await fetchApi('/api/admin/activity_log', {
          method: 'POST',
          body: JSON.stringify({
            action: 'Media Ingested',
            details: \`Uploaded file to CDN pipeline: \${file.name}\`
          })
        });
      } catch (e) {}`
);

fs.writeFileSync('src/pages/admin/AdminMedia.tsx', content, 'utf-8');
console.log("Updated AdminMedia.tsx upload logic");
