import dotenv from 'dotenv';
dotenv.config();

const secret = process.env.sb_secret_IJiNLgQVttupqnV9TlGKlg_sLKelp4F || '';
console.log("Length:", secret.length);
if (secret.length > 8) {
  console.log("Starts with:", secret.substring(0, 4));
  console.log("Ends with:", secret.substring(secret.length - 4));
  console.log("Is alphanumeric:", /^[a-zA-Z0-9]+$/.test(secret));
  console.log("Has special characters:", /[^a-zA-Z0-9]/.test(secret));
} else {
  console.log("Secret is too short.");
}
