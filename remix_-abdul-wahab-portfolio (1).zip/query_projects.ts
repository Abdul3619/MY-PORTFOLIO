import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

const supabase = createClient(supabaseUrl, serviceKey);

async function checkProjects() {
  const { data, error } = await supabase.from('projects').select('*');
  if (error) {
    console.error("Error fetching projects:", error);
  } else {
    console.log("Success! Projects data:", data);
  }
}

checkProjects();
