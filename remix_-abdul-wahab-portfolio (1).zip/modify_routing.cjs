const fs = require('fs');

// Modify App.tsx
let appContent = fs.readFileSync('src/App.tsx', 'utf-8');
appContent = appContent.replace(
  'import AdminSettings from "./pages/admin/AdminSettings";',
  'import AdminSettings from "./pages/admin/AdminSettings";\nimport AdminSiteSettings from "./pages/admin/AdminSiteSettings";'
);
appContent = appContent.replace(
  '<Route path="/admin/profile" element={<AdminSettings />} />',
  '<Route path="/admin/profile" element={<AdminSettings />} />\n            <Route path="/admin/settings" element={<AdminSiteSettings />} />'
);
fs.writeFileSync('src/App.tsx', appContent, 'utf-8');

// Modify AdminLayout.tsx
let layoutContent = fs.readFileSync('src/components/admin/AdminLayout.tsx', 'utf-8');
layoutContent = layoutContent.replace(
  `<Link to="/admin/profile" className={\`flex flex-col items-center justify-center w-12 h-12 rounded \${location.pathname === '/admin/profile' ? 'text-[#00F0FF]' : 'hover:text-white'}\`}>
            <Settings size={18} />
            <span className="text-[8px] mt-0.5 font-mono">Settings</span>
          </Link>`,
  `<Link to="/admin/profile" className={\`flex flex-col items-center justify-center w-12 h-12 rounded \${location.pathname === '/admin/profile' ? 'text-[#00F0FF]' : 'hover:text-white'}\`}>
            <User size={18} />
            <span className="text-[8px] mt-0.5 font-mono">Profile</span>
          </Link>
          <Link to="/admin/settings" className={\`flex flex-col items-center justify-center w-12 h-12 rounded \${location.pathname === '/admin/settings' ? 'text-[#00F0FF]' : 'hover:text-white'}\`}>
            <Settings size={18} />
            <span className="text-[8px] mt-0.5 font-mono">Settings</span>
          </Link>`
);
fs.writeFileSync('src/components/admin/AdminLayout.tsx', layoutContent, 'utf-8');

console.log("Updated routing and sidebar");
