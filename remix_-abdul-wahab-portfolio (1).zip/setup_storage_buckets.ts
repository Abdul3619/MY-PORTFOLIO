import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

const supabase = createClient(supabaseUrl, serviceKey);

async function setupBuckets() {
  console.log("Checking storage buckets...");
  
  const { data: buckets, error: listError } = await supabase.storage.listBuckets();
  if (listError) {
    console.error("Error listing buckets:", listError.message);
    return;
  }

  console.log("Current buckets:", buckets.map(b => b.name));

  const requiredBuckets = ['images', 'documents', 'media'];

  for (const bucketName of requiredBuckets) {
    if (buckets.some(b => b.name === bucketName)) {
      console.log(`Bucket "${bucketName}" already exists.`);
    } else {
      console.log(`Creating bucket "${bucketName}"...`);
      const { data, error } = await supabase.storage.createBucket(bucketName, {
        public: true,
        allowedMimeTypes: bucketName === 'images' ? ['image/*'] : undefined,
        fileSizeLimit: 5242880, // 5MB
      });
      if (error) {
        console.error(`Error creating bucket "${bucketName}":`, error.message);
      } else {
        console.log(`Bucket "${bucketName}" created successfully.`);
      }
    }
  }
}

setupBuckets();
