import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

const supabase = createClient(supabaseUrl, serviceKey);

async function showRow() {
  const { data, error } = await supabase.from('projects').select('*').limit(1).single();
  if (error) {
    console.error("Error retrieving row:", error.message);
  } else {
    console.log("Confirmed seeded project row in Supabase projects table:");
    console.log(JSON.stringify(data, null, 2));
  }
}

showRow();
