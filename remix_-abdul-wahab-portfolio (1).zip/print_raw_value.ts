import dotenv from 'dotenv';
dotenv.config();

const val = process.env['sb_secret_IJiNLgQVttupqnV9TlGKlg_sLKelp4F'];
console.log("Raw value in env:", JSON.stringify(val));
