const fs = require('fs');

let content = fs.readFileSync('src/hooks/useApi.ts', 'utf-8');

content = content.replace(
  `const headers: HeadersInit = {
    'Content-Type': 'application/json',
  };`,
  `const headers: HeadersInit = {};
  if (!(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json';
  }`
);

fs.writeFileSync('src/hooks/useApi.ts', content, 'utf-8');
console.log("Fixed fetchApi for FormData");
