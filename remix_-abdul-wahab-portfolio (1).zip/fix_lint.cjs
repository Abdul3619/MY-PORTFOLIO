const fs = require('fs');

// Fix AdminMedia.tsx
let mediaContent = fs.readFileSync('src/pages/admin/AdminMedia.tsx', 'utf-8');
mediaContent = mediaContent.replace(
  'name: responseData.name || file.name,\n            id: file.id',
  'name: file.name,\n            id: file.id'
);
fs.writeFileSync('src/pages/admin/AdminMedia.tsx', mediaContent, 'utf-8');

// Fix AdminSiteSettings.tsx
let settingsContent = fs.readFileSync('src/pages/admin/AdminSiteSettings.tsx', 'utf-8');
settingsContent = settingsContent.replace(
  "triggerToast('success', 'Settings Saved', 'Your site settings have been updated successfully.');",
  "triggerToast('Settings Saved', 'Your site settings have been updated successfully.', 'success');"
);
settingsContent = settingsContent.replace(
  "triggerToast('danger', 'Save Failed', err.message || 'An error occurred while saving.');",
  "triggerToast('Save Failed', err.message || 'An error occurred while saving.', 'danger');"
);
fs.writeFileSync('src/pages/admin/AdminSiteSettings.tsx', settingsContent, 'utf-8');

console.log("Lint errors fixed");
