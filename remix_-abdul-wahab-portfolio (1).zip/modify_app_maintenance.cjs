const fs = require('fs');

let appContent = fs.readFileSync('src/App.tsx', 'utf-8');

appContent = appContent.replace(
  'import AdminSiteSettings from "./pages/admin/AdminSiteSettings";',
  'import AdminSiteSettings from "./pages/admin/AdminSiteSettings";\nimport Maintenance from "./pages/Maintenance";'
);

appContent = appContent.replace(
  '<Route element={<Layout><Outlet /></Layout>}>',
  `{seo?.maintenance_mode ? (
          <Route element={<Outlet />}>
            <Route path="/" element={<Maintenance />} />
            <Route path="*" element={<Maintenance />} />
          </Route>
        ) : (
          <Route element={<Layout><Outlet /></Layout>}>`
);

appContent = appContent.replace(
  '<Route path="/contact" element={<Contact />} />\n        </Route>',
  '<Route path="/contact" element={<Contact />} />\n        </Route>\n        )}'
);

fs.writeFileSync('src/App.tsx', appContent, 'utf-8');
console.log("Updated App.tsx with Maintenance Mode");
