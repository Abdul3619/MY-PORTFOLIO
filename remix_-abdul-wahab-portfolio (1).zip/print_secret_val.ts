import dotenv from 'dotenv';
dotenv.config();

const secret = process.env.sb_secret_IJiNLgQVttupqnV9TlGKlg_sLKelp4F || '';
console.log("Secret value:", secret);
