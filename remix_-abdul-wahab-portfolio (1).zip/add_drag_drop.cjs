const fs = require('fs');

let content = fs.readFileSync('src/pages/admin/AdminMedia.tsx', 'utf-8');

// Add drag state
content = content.replace(
  'const [copiedName, setCopiedName] = useState<string | null>(null);',
  'const [copiedName, setCopiedName] = useState<string | null>(null);\n  const [isDragging, setIsDragging] = useState(false);'
);

// Add drop handlers
const dropHandlers = `
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };
  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };
  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files?.[0];
    if (file) {
      await processFile(file);
    }
  };
`;

content = content.replace(
  'const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {',
  `${dropHandlers}\n  const processFile = async (file: File) => {`
);

content = content.replace(
  'const file = e.target.files?.[0];\n    if (!file) return;',
  'if (!file) return;'
);

content = content.replace(
  '<label className="border-2 border-dashed border-white/10 hover:border-[#00F0FF]/50 rounded-lg bg-[#161616]/50 hover:bg-[#161616] transition-colors p-6 flex flex-col items-center justify-center cursor-pointer interactive">',
  '<label \n                onDragOver={handleDragOver}\n                onDragLeave={handleDragLeave}\n                onDrop={handleDrop}\n                className={`border-2 border-dashed rounded-lg transition-colors p-6 flex flex-col items-center justify-center cursor-pointer interactive ${isDragging ? "border-[#00F0FF] bg-[#00F0FF]/10" : "border-white/10 hover:border-[#00F0FF]/50 bg-[#161616]/50 hover:bg-[#161616]"}`}>'
);

content = content.replace(
  'const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {',
  `const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) await processFile(file);
  };`
);

// Wait, the processFile wrapper might be slightly messy if I just replace it like that. Let's do it safely.
