import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

async function fetchSchema() {
  try {
    const res = await fetch(`${supabaseUrl}/rest/v1/`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${serviceKey}`,
        'apikey': serviceKey
      }
    });
    console.log("Status:", res.status);
    const data = await res.json();
    console.log("Paths in schema:");
    if (data.paths) {
      Object.keys(data.paths).forEach(p => {
        console.log(`- ${p}`);
      });
    } else {
      console.log("No paths found or format is different.");
    }
  } catch (err: any) {
    console.error("Error:", err.message);
  }
}

fetchSchema();
