import fs from 'fs';
import path from 'path';

const dir = '/etc/secrets';
try {
  if (fs.existsSync(dir)) {
    const files = fs.readdirSync(dir);
    console.log("Files in /etc/secrets:", files);
    for (const file of files) {
      const fullPath = path.join(dir, file);
      const content = fs.readFileSync(fullPath, 'utf8');
      console.log(`\n--- ${file} (length: ${content.length}) ---`);
      // Censor the actual secret value but print the general format and first/last characters
      if (content.length > 6) {
        console.log(`Starts with: ${content.substring(0, 3)}... Ends with: ${content.substring(content.length - 3)}`);
      } else {
        console.log(`Value: ${content}`);
      }
    }
  } else {
    console.log("/etc/secrets does not exist.");
  }
} catch (err: any) {
  console.error("Error:", err.message);
}
