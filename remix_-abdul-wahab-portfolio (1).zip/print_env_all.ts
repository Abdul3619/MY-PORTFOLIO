import dotenv from 'dotenv';
dotenv.config();

console.log("Environment check:");
for (const [key, value] of Object.entries(process.env)) {
  if (!value) continue;
  const valLower = value.toLowerCase();
  const keyLower = key.toLowerCase();
  
  if (keyLower.includes('supabase') || valLower.includes('supabase') || keyLower.includes('pass') || valLower.includes('pass') || valLower.includes('postgres')) {
    console.log(`- ${key}: length=${value.length}, value=${value.substring(0, 10)}... (censor)`);
  }
}
