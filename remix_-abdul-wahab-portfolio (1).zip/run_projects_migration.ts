import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
dotenv.config();

const supabaseUrl = process.env.VITE_SUPABASE_URL || '';
const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY || '';

const supabaseAdmin = createClient(supabaseUrl, serviceKey, {
  auth: { autoRefreshToken: false, persistSession: false }
});

async function run() {
  const sql = `
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS long_description TEXT;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS tech_stack JSONB DEFAULT '[]'::jsonb;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS tags JSONB DEFAULT '[]'::jsonb;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS client_name TEXT;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS completion_date TEXT;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS status TEXT DEFAULT 'Completed';
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS seo_title TEXT;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS seo_description TEXT;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS gallery_images JSONB DEFAULT '[]'::jsonb;
    ALTER TABLE public.projects ADD COLUMN IF NOT EXISTS sort_order INTEGER DEFAULT 0;
  `;
  
  // Try using 'exec_sql' RPC
  console.log("Attempting migration via 'exec_sql' RPC...");
  const { error } = await supabaseAdmin.rpc('exec_sql', { sql_query: sql });
  if (error) {
    console.error("exec_sql failed:", error.message);
  } else {
    console.log("Migration successful!");
  }
}
run();
