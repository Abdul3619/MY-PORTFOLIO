import fs from 'fs';
import path from 'path';

const searchDirs = ['/etc', '/run', '/var', '/opt', '/home'];
const now = Date.now();

function scan(dir: string, depth = 0) {
  if (depth > 2) return;
  try {
    const files = fs.readdirSync(dir);
    for (const file of files) {
      const p = path.join(dir, file);
      try {
        const stat = fs.statSync(p);
        if (stat.isFile() && (now - stat.mtimeMs < 12 * 60 * 60 * 1000)) { // modified in last 12 hours
          console.log(`Recent file: ${p} (size: ${stat.size}, mtime: ${stat.mtime})`);
        }
        if (stat.isDirectory()) {
          scan(p, depth + 1);
        }
      } catch (e) {}
    }
  } catch (err) {}
}

for (const d of searchDirs) {
  scan(d);
}
console.log("Scan finished.");
